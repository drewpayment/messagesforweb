##Messages for Web

This is a Chrome Extension that simply wraps the Android Messages for Web web application into a bare browser shell, so that the 
user isn't distracted with all of the clutter of a standard Chrome browser. 

Unaffiliated with Google or Android development teams, 100% open source and hopefully will continue to develop new features 
that coincide with the web application. 

### CHANGELOG

0.1.0 --- Initial version, public release.
0.1.1 --- Fixed 16x16 icon so that icon looks right on taskbars and in Chrome extension menu (cut me some slack guys, I'm no graphic designer).